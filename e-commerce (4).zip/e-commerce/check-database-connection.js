const { models, sequelize } = require('./server/models');
const path = require('path');

async function checkDatabaseConnection() {
  try {
    console.log('🔍 DATABASE CONNECTION INVESTIGATION');
    console.log('=' .repeat(60));
    
    // Check what database the server is actually using
    console.log('\n💾 DATABASE CONNECTION INFO:');
    console.log('   DATABASE_URL env var:', process.env.DATABASE_URL || 'Not set');
    console.log('   Default path:', path.join(__dirname, 'server', 'data', 'matinacloset.sqlite'));
    
    // Get the actual database URL from sequelize
    const config = sequelize.config;
    console.log('   Sequelize dialect:', config.dialect);
    console.log('   Sequelize storage:', config.storage || 'In-memory');
    
    // Test database connection
    console.log('\n🔗 TESTING DATABASE CONNECTION:');
    await sequelize.authenticate();
    console.log('   ✅ Database connection successful');
    
    // Check all users in the connected database
    console.log('\n👥 USERS IN CONNECTED DATABASE:');
    const users = await models.User.findAll({
      attributes: ['id', 'name', 'email', 'role', 'createdAt'],
      order: [['id', 'ASC']]
    });
    
    console.log(`   Total users: ${users.length}`);
    users.forEach(user => {
      console.log(`   ID ${user.id}: ${user.name} (${user.email}) - ${user.role}`);
      console.log(`      Created: ${user.createdAt}`);
    });
    
    // Specifically check for Kelvin
    const kelvinUser = await models.User.findOne({
      where: { email: 'kelvin@gmail.com' }
    });
    
    console.log('\n🎯 KELVIN USER CHECK:');
    if (kelvinUser) {
      console.log('   ❌ KELVIN EXISTS IN CONNECTED DATABASE!');
      console.log(`   ID: ${kelvinUser.id}`);
      console.log(`   Name: ${kelvinUser.name}`);
      console.log(`   Email: ${kelvinUser.email}`);
      console.log(`   Role: ${kelvinUser.role}`);
      console.log(`   Created: ${kelvinUser.createdAt}`);
      console.log(`   Password hash: ${kelvinUser.password.substring(0, 20)}...`);
      
      console.log('\n🤔 THIS EXPLAINS WHY LOGIN WORKS!');
      console.log('   Kelvin user exists in the database that the server is using');
      console.log('   Our previous checks might have been looking at a different database');
      
    } else {
      console.log('   ✅ Kelvin not found in connected database');
      console.log('   This is very strange - login should not work');
    }
    
    // Check if there are multiple database files
    console.log('\n📁 CHECKING FOR MULTIPLE DATABASE FILES:');
    const fs = require('fs');
    const dataDir = path.join(__dirname, 'server', 'data');
    
    try {
      const files = fs.readdirSync(dataDir);
      const dbFiles = files.filter(file => file.endsWith('.sqlite'));
      
      console.log(`   Database files in ${dataDir}:`);
      dbFiles.forEach(file => {
        const filePath = path.join(dataDir, file);
        const stats = fs.statSync(filePath);
        console.log(`   • ${file} (${stats.size} bytes, modified: ${stats.mtime})`);
      });
      
      if (dbFiles.length > 1) {
        console.log('\n⚠️ MULTIPLE DATABASE FILES FOUND!');
        console.log('   This could explain the confusion');
      }
      
    } catch (error) {
      console.log('   Error reading database directory:', error.message);
    }
    
    console.log('\n🎯 CONCLUSION:');
    if (kelvinUser) {
      console.log('   ✅ Kelvin exists in the server database');
      console.log('   🔧 Delete Kelvin from this database to fix the issue');
    } else {
      console.log('   ❌ Kelvin does not exist but login still works');
      console.log('   🔍 This indicates a deeper issue');
    }
    
  } catch (error) {
    console.error('Database connection check error:', error);
  }
  
  await sequelize.close();
  process.exit(0);
}

checkDatabaseConnection();
