// Test the exact same database connection the server uses
require('dotenv').config();
const path = require('path');
const { Sequelize, DataTypes } = require('sequelize');

const databaseUrl = process.env.DATABASE_URL || `sqlite:${path.join(__dirname, 'server', 'data', 'matinacloset.sqlite')}`;
const sequelize = new Sequelize(databaseUrl, { logging: false });

// Define User model exactly like the server
const User = sequelize.define('User', {
  id: { type: DataTypes.INTEGER, autoIncrement: true, primaryKey: true },
  name: { type: DataTypes.STRING, allowNull: false },
  email: { type: DataTypes.STRING, allowNull: false, unique: true, validate: { isEmail: true } },
  password: { type: DataTypes.STRING, allowNull: false },
  role: { type: DataTypes.ENUM('user', 'admin'), allowNull: false, defaultValue: 'user' },
}, { timestamps: true });

async function checkServerDB() {
  try {
    console.log('🔍 Checking server database connection...');
    console.log('📁 Database URL:', databaseUrl);
    
    await sequelize.authenticate();
    console.log('✅ Database connected');
    
    const admin = await User.findOne({ where: { email: 'admin@matinacloset.com' } });
    if (admin) {
      console.log('✅ Admin user found:', { id: admin.id, email: admin.email, role: admin.role });
      
      const bcrypt = require('bcryptjs');
      const isValid = await bcrypt.compare('Admin123!', admin.password);
      console.log('🔐 Password verification:', isValid);
    } else {
      console.log('❌ Admin user not found');
      
      // Check all users
      const allUsers = await User.findAll();
      console.log('👥 All users in database:', allUsers.map(u => ({ id: u.id, email: u.email, role: u.role })));
    }
    
    await sequelize.close();
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

checkServerDB();
