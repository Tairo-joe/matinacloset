const { models } = require('./server/models');

async function comprehensiveCartDebug() {
  try {
    console.log('🔍 COMPREHENSIVE CART DEBUG - SOLVING ONCE AND FOR ALL');
    console.log('=' .repeat(60));
    
    // 1. Check database state
    console.log('\n📊 DATABASE STATE:');
    const products = await models.Product.findAll({
      attributes: ['id', 'name', 'price', 'stock'],
      order: [['id', 'ASC']]
    });
    
    console.log(`   Products found: ${products.length}`);
    products.forEach(p => {
      console.log(`   ✅ ID ${p.id}: ${p.name} (Price: ${p.price}, Stock: ${p.stock})`);
    });
    
    if (products.length === 0) {
      console.log('\n❌ ROOT CAUSE: NO PRODUCTS IN DATABASE!');
      console.log('   SOLUTION: Create products first through admin panel');
      console.log('   This explains why "Add to bag" fails - nothing to add!');
      return;
    }
    
    // 2. Test cart functionality step by step
    console.log('\n🧪 STEP-BY-STEP CART TESTING:');
    
    const testUserId = 2;
    const testProduct = products[0];
    
    console.log(`   Using test product: ID ${testProduct.id} (${testProduct.name})`);
    
    // Step 1: Clear cart
    console.log('   Step 1: Clearing existing cart...');
    await models.CartItem.destroy({ where: { userId: testUserId } });
    console.log('   ✅ Cart cleared');
    
    // Step 2: Test direct database insert
    console.log('   Step 2: Testing direct database insert...');
    try {
      const directInsert = await models.CartItem.create({
        userId: testUserId,
        productId: testProduct.id,
        quantity: 1
      });
      console.log(`   ✅ Direct insert successful: CartItem ID ${directInsert.id}`);
      
      // Verify it exists
      const verifyItem = await models.CartItem.findOne({
        where: { id: directInsert.id },
        include: [{ model: models.Product }]
      });
      console.log(`   ✅ Verification: ${verifyItem.Product.name} in cart`);
      
      // Clean up for API test
      await models.CartItem.destroy({ where: { id: directInsert.id } });
      
    } catch (error) {
      console.log(`   ❌ Direct insert failed: ${error.message}`);
      console.log('   SOLUTION: Database constraint issues - fix CartItem table');
      return;
    }
    
    // Step 3: Test API route manually
    console.log('   Step 3: Testing API route manually...');
    try {
      // Simulate API call
      const mockReq = {
        user: { id: testUserId },
        body: {
          productId: testProduct.id,
          quantity: 1,
          size: null,
          color: null
        }
      };
      
      // Check if product exists (API validation)
      const productCheck = await models.Product.findByPk(mockReq.body.productId);
      if (!productCheck) {
        console.log('   ❌ API would fail: Product not found');
        return;
      }
      
      // Check for existing item (API logic)
      const existingItem = await models.CartItem.findOne({
        where: { 
          userId: mockReq.user.id, 
          productId: mockReq.body.productId, 
          size: mockReq.body.size || null, 
          color: mockReq.body.color || null 
        }
      });
      
      if (existingItem) {
        console.log('   ✅ API would update existing item');
        await existingItem.update({ quantity: existingItem.quantity + mockReq.body.quantity });
      } else {
        console.log('   ✅ API would create new item');
        await models.CartItem.create({
          userId: mockReq.user.id,
          productId: mockReq.body.productId,
          quantity: mockReq.body.quantity,
          size: mockReq.body.size || null,
          color: mockReq.body.color || null
        });
      }
      
      console.log('   ✅ API logic test successful');
      
    } catch (error) {
      console.log(`   ❌ API logic test failed: ${error.message}`);
      console.log('   SOLUTION: Fix API route implementation');
      return;
    }
    
    // 4. Check user authentication
    console.log('\n👤 USER AUTHENTICATION CHECK:');
    const users = await models.User.findAll({
      attributes: ['id', 'name', 'email', 'role'],
      order: [['id', 'ASC']]
    });
    
    console.log(`   Users found: ${users.length}`);
    users.forEach(u => {
      console.log(`   ✅ ID ${u.id}: ${u.name} (${u.email}) - ${u.role}`);
    });
    
    if (users.length === 0) {
      console.log('   ❌ No users found - authentication will fail');
      console.log('   SOLUTION: Create admin user or login properly');
      return;
    }
    
    // 5. Final diagnosis
    console.log('\n🎯 FINAL DIAGNOSIS:');
    console.log('   ✅ Database: Working');
    console.log('   ✅ Products: Exist');
    console.log('   ✅ Cart table: Working');
    console.log('   ✅ API logic: Working');
    console.log('   ✅ Users: Exist');
    
    console.log('\n💡 MOST LIKELY ISSUES:');
    console.log('   1. Frontend not sending correct product IDs');
    console.log('   2. User not properly authenticated in browser');
    console.log('   3. Frontend JavaScript errors');
    console.log('   4. Network/CORS issues');
    
    console.log('\n🔧 NEXT STEPS:');
    console.log('   1. Open browser developer tools');
    console.log('   2. Check Network tab when clicking "Add to bag"');
    console.log('   3. Look for specific error messages');
    console.log('   4. Check Console tab for JavaScript errors');
    console.log('   5. Verify user is logged in (check localStorage)');
    
  } catch (error) {
    console.error('Debug error:', error);
  }
  
  process.exit(0);
}

comprehensiveCartDebug();
