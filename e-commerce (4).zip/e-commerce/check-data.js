const { sequelize, models } = require('./server/models');

async function checkData() {
  try {
    const userCount = await models.User.count();
    const productCount = await models.Product.count();
    
    console.log('📊 Current database state:');
    console.log('   Users:', userCount);
    console.log('   Products:', productCount);
    
    if (userCount > 0) {
      const admin = await models.User.findOne({ where: { role: 'admin' } });
      console.log('   Admin user:', admin ? '✅ Exists' : '❌ Missing');
    }
    
    if (productCount > 0) {
      const products = await models.Product.findAll({ 
        attributes: ['id', 'name', 'sizes', 'colors'],
        limit: 3
      });
      console.log('   Sample products:');
      products.forEach(p => {
        console.log(`     - ${p.name} (Sizes: ${p.sizes?.length || 0}, Colors: ${p.colors?.length || 0})`);
      });
    }
    
    await sequelize.close();
  } catch (error) {
    console.error('❌ Error:', error.message);
  }
}

checkData();
