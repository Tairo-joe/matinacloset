const sqlite3 = require('sqlite3').verbose();
const path = require('path');

async function checkDatabaseStructure() {
  try {
    console.log('🔍 DATABASE STRUCTURE INSPECTION');
    console.log('=' .repeat(60));
    
    const dbPath = path.join(__dirname, 'server', 'data', 'matinacloset.sqlite');
    console.log(`\n💾 Database file: ${dbPath}`);
    
    // Open database directly
    const db = new sqlite3.Database(dbPath);
    
    console.log('\n📋 TABLE STRUCTURE:');
    
    // Get all tables
    db.all("SELECT name FROM sqlite_master WHERE type='table'", (err, tables) => {
      if (err) {
        console.error('❌ Error getting tables:', err);
        return;
      }
      
      console.log(`   Tables found: ${tables.length}`);
      tables.forEach(table => {
        console.log(`   • ${table.name}`);
      });
      
      // Get Users table structure
      console.log('\n👥 USERS TABLE STRUCTURE:');
      db.all("PRAGMA table_info(Users)", (err, columns) => {
        if (err) {
          console.error('❌ Error getting Users table structure:', err);
          return;
        }
        
        console.log('   Columns:');
        columns.forEach(col => {
          console.log(`   • ${col.name} (${col.type}) - ${col.notnull ? 'NOT NULL' : 'NULL'}${col.pk ? ' PRIMARY KEY' : ''}`);
        });
        
        // Query all users with correct column names
        const userColumns = columns.map(col => col.name).join(', ');
        db.all(`SELECT ${userColumns} FROM Users`, (err, rows) => {
          if (err) {
            console.error('❌ Error querying users:', err);
            return;
          }
          
          console.log(`\n👥 ALL USERS IN DATABASE:`);
          console.log(`   Total users: ${rows.length}`);
          
          rows.forEach(user => {
            console.log(`   ID ${user.id}: ${user.name} (${user.email}) - ${user.role}`);
            // Show creation date if it exists
            if (user.createdAt) console.log(`      Created: ${user.createdAt}`);
            else if (user.created_at) console.log(`      Created: ${user.created_at}`);
          });
          
          // Specifically check for Kelvin
          console.log('\n🎯 KELVIN USER SEARCH:');
          db.all("SELECT * FROM Users WHERE email = 'kelvin@gmail.com'", (err, kelvinRows) => {
            if (err) {
              console.error('❌ Error searching for Kelvin:', err);
              return;
            }
            
            if (kelvinRows.length > 0) {
              console.log('   ❌ KELVIN FOUND IN DATABASE:');
              kelvinRows.forEach(kelvin => {
                console.log(`   ID: ${kelvin.id}`);
                console.log(`   Name: ${kelvin.name}`);
                console.log(`   Email: ${kelvin.email}`);
                console.log(`   Role: ${kelvin.role}`);
                if (kelvin.createdAt) console.log(`   Created: ${kelvin.createdAt}`);
                else if (kelvin.created_at) console.log(`   Created: ${kelvin.created_at}`);
                console.log(`   Password hash: ${kelvin.password ? kelvin.password.substring(0, 20) + '...' : 'NULL'}`);
              });
              
              // Delete Kelvin
              console.log('\n🗑️ DELETING KELVIN:');
              db.run("DELETE FROM Users WHERE email = 'kelvin@gmail.com'", function(err) {
                if (err) {
                  console.error('❌ Error deleting Kelvin:', err);
                } else {
                  console.log(`   ✅ Deleted ${this.changes} Kelvin user(s)`);
                  
                  // Delete cart items for user ID 2 (Kelvin's ID)
                  db.run("DELETE FROM CartItems WHERE userId = ?", [2], function(err) {
                    if (err) {
                      console.error('❌ Error deleting cart items:', err);
                    } else {
                      console.log(`   ✅ Deleted ${this.changes} cart items for user ID 2`);
                    }
                    
                    console.log('\n🚀 KELVIN PERMANENTLY DELETED!');
                    console.log('   • Removed from database file');
                    console.log('   • Cart items cleaned up');
                    console.log('   • Restart server and test again');
                    
                    db.close();
                  });
                }
              });
              
            } else {
              console.log('   ✅ Kelvin not found in database file');
              console.log('   This is extremely strange...');
              
              // Check for similar emails
              db.all("SELECT email FROM Users WHERE email LIKE '%kelvin%'", (err, similarRows) => {
                if (err) {
                  console.error('❌ Error searching similar emails:', err);
                } else {
                  console.log(`\n🔍 USERS WITH 'kelvin' IN EMAIL:`);
                  if (similarRows.length === 0) {
                    console.log('   None found');
                  } else {
                    similarRows.forEach(row => {
                      console.log(`   • ${row.email}`);
                    });
                  }
                }
                
                db.close();
              });
            }
          });
        });
      });
    });
    
  } catch (error) {
    console.error('Database structure check error:', error);
  }
}

checkDatabaseStructure();
