const { models } = require('./server/models');

async function cleanupUsers() {
  try {
    console.log('🗑️ CLEANING UP USERS - KEEPING ONLY ADMIN');
    console.log('=' .repeat(50));
    
    // Get all users
    const allUsers = await models.User.findAll({
      attributes: ['id', 'name', 'email', 'role'],
      order: [['id', 'ASC']]
    });
    
    console.log('\n📋 ALL USERS IN DATABASE:');
    allUsers.forEach(user => {
      console.log(`   ID ${user.id}: ${user.name} (${user.email}) - ${user.role}`);
    });
    
    // Delete all users except admin
    const usersToDelete = allUsers.filter(user => user.role !== 'admin');
    
    if (usersToDelete.length === 0) {
      console.log('\n✅ No non-admin users to delete');
    } else {
      console.log(`\n🗑️ DELETING ${usersToDelete.length} NON-ADMIN USERS:`);
      
      for (const user of usersToDelete) {
        // Delete cart items for this user first
        await models.CartItem.destroy({ where: { userId: user.id } });
        
        // Delete the user
        await models.User.destroy({ where: { id: user.id } });
        console.log(`   ❌ Deleted: ${user.name} (${user.email})`);
      }
    }
    
    // Clear cart items for admin too
    const adminUser = allUsers.find(user => user.role === 'admin');
    if (adminUser) {
      await models.CartItem.destroy({ where: { userId: adminUser.id } });
      console.log(`\n🧹 Cleared cart for admin: ${adminUser.name}`);
    }
    
    // Verify final state
    const remainingUsers = await models.User.findAll({
      attributes: ['id', 'name', 'email', 'role'],
      order: [['id', 'ASC']]
    });
    
    console.log('\n✅ FINAL USERS IN DATABASE:');
    remainingUsers.forEach(user => {
      console.log(`   ID ${user.id}: ${user.name} (${user.email}) - ${user.role}`);
    });
    
    console.log('\n🚀 USER CLEANUP COMPLETE!');
    console.log('   • Only admin user remains');
    console.log('   • All cart items cleared');
    console.log('   • Ready for fresh testing');
    
  } catch (error) {
    console.error('Error cleaning up users:', error);
  }
  
  process.exit(0);
}

cleanupUsers();
